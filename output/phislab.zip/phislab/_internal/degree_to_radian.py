from math import  radians

def degree_to_radians(grad):
    return radians(grad)