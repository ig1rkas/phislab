import tkinter as tk

def take_format(): 
    root = tk.Tk()
    
    return root.winfo_screenwidth() / 16, root.winfo_screenheight() / 9
